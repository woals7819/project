package com;

public class NomalSignalDTO {
	private int tagnumber;
	private String signal;
	private String equipmentname;
	private String tagname;
	private String signame;
	private String description;
	private String sigtype;
	private int englow;
	private int enghigh;
	private String unit;
	private String alarm;
	private int staytime;
	private int ll;
	private int l;
	private int h;
	private int hh;
	private int di;
	private String sourcetagname;
	private int signalbit;
	private int decimalpoint;
	
	
	
	
	
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public String getSignal() {
		return signal;
	}
	public void setSignal(String signal) {
		this.signal = signal;
	}
	public String getEquipmentname() {
		return equipmentname;
	}
	public void setEquipmentname(String equipmentname) {
		this.equipmentname = equipmentname;
	}
	public String getTagname() {
		return tagname;
	}
	public void setTagname(String tagname) {
		this.tagname = tagname;
	}
	public String getSigname() {
		return signame;
	}
	public void setSigname(String signame) {
		this.signame = signame;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSigtype() {
		return sigtype;
	}
	public void setSigtype(String sigtype) {
		this.sigtype = sigtype;
	}
	public int getEnglow() {
		return englow;
	}
	public void setEnglow(int englow) {
		this.englow = englow;
	}
	public int getEnghigh() {
		return enghigh;
	}
	public void setEnghigh(int enghigh) {
		this.enghigh = enghigh;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getAlarm() {
		return alarm;
	}
	public void setAlarm(String alarm) {
		this.alarm = alarm;
	}
	public int getStaytime() {
		return staytime;
	}
	public void setStaytime(int staytime) {
		this.staytime = staytime;
	}
	public int getLl() {
		return ll;
	}
	public void setLl(int ll) {
		this.ll = ll;
	}
	public int getL() {
		return l;
	}
	public void setL(int l) {
		this.l = l;
	}
	public int getH() {
		return h;
	}
	public void setH(int h) {
		this.h = h;
	}
	public int getHh() {
		return hh;
	}
	public void setHh(int hh) {
		this.hh = hh;
	}
	public int getDi() {
		return di;
	}
	public void setDi(int di) {
		this.di = di;
	}
	public String getSourcetagname() {
		return sourcetagname;
	}
	public void setSourcetagname(String sourcetagname) {
		this.sourcetagname = sourcetagname;
	}
	public int getSignalbit() {
		return signalbit;
	}
	public void setSignalbit(int signalbit) {
		this.signalbit = signalbit;
	}
	public int getDecimalpoint() {
		return decimalpoint;
	}
	public void setDecimalpoint(int decimalpoint) {
		this.decimalpoint = decimalpoint;
	}
	
	
	
	
	
	

}
