package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class TE
 */
@WebServlet("/TE")
public class TE extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		response.setCharacterEncoding("UTF-8");
//		response.setContentType("text/html; charset=UTF-8");
//		
//		String[] UpdateData = request.getParameterValues("Updaterowdata");
//		String[] DeleteData = request.getParameterValues("DeleteRowData");
//		
//		TagDAO tdao = new TagDAO();
//		try {
//			
//			if(UpdateData != null) {
//				System.out.println("UpdateData success");
//				
//				
//				String Tagnumber =UpdateData[0];
//				String Signal = UpdateData[1];
//				String Equipmentname=UpdateData[2];
//				String Tagname=UpdateData[3];
//				String Signame=UpdateData[4];
//				String Description=UpdateData[5];
//				String Sigtype=UpdateData[6];
//				String Englow=UpdateData[7];
//				String Enghigh=UpdateData[8];
//				String Unit=UpdateData[9];
//				String Alarm=UpdateData[10];
//				String Staytime=UpdateData[11];
//				String Ll=UpdateData[12];
//				String L=UpdateData[13];
//				String H=UpdateData[14];
//				String Hh=UpdateData[15];
//				String Di=UpdateData[16];
//				String Sourcetagname=UpdateData[17];
//				String Signalbit=UpdateData[18];
//				String Decimalpoint=UpdateData[19];
//				
//				
//				
//				ArrayList<String> ndto = new ArrayList<String>();
//				
//				ndto.add(Tagnumber);
//				ndto.add(Signal);
//				ndto.add(Equipmentname);
//				ndto.add(Tagname);
//				ndto.add(Signame);
//				ndto.add(Decimalpoint);
//				ndto.add(Sigtype);
//				ndto.add(Englow);
//				ndto.add(Enghigh);
//				ndto.add(Unit);
//				ndto.add(Alarm);
//				ndto.add(Staytime);
//				ndto.add(Ll);
//				ndto.add(L);
//				ndto.add(H);
//				ndto.add(Hh);
//				ndto.add(Di);
//				ndto.add(Sourcetagname);
//				ndto.add(Signalbit);
//				ndto.add(Decimalpoint);
//				
//				
//				for(int i = 0; i < ndto.size(); i++) {
//					System.out.println(ndto.get(i));
//				}
//				
//				
//				request.setAttribute("ndto", ndto);
//				
//				
//				RequestDispatcher rd = request.getRequestDispatcher("SignalUpdate.jsp");
//				rd.forward(request, response);
//				
//			}
//			else if(DeleteData != null) {
//				System.out.println("DeleteData success");
//			}
//		}
//		catch (NumberFormatException e) {
//			e.printStackTrace();
//		}
//		
//		
//		
//		
//	}
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		
		TagDAO tdao = new TagDAO();

		try {
			
			String page = "";
			String[] s = request.getParameterValues("rowdata");
			try {
				if(s != null) {
					System.out.println("����");
					for(int i = 0; i < s.length; i++) {
						System.out.println(s[i]);
						
						ArrayList<NomalSignalDTO> ndto = tdao.sdsd(s);
						
						System.out.println(ndto.size());
						
						request.setAttribute("ndto", ndto);
						
						RequestDispatcher rd = request.getRequestDispatcher("SignalUpdate.jsp");
						rd.include(request, response);
					}
				}
				
			}catch (Exception e) {
				page = "SignalUpdate.jsp";
			}
			
			
			
			
//			int size = data.length;
//			System.out.println(size);
			
			String action = request.getParameter("action");
			if(action != null) {
				if(action.equals("AllSignal")) {
					List<AllSignalDTO> list = tdao.AllSignalList();
					request.setAttribute("list", list);
				
					RequestDispatcher rd = request.getRequestDispatcher("AllSignal.jsp");
					rd.forward(request, response);
				}
			
				else if(action.equals("NomalSignal")) {
					List<NomalSignalDTO> nomallist = tdao.NomalSignalList();
					request.setAttribute("nomallist", nomallist);
				
					RequestDispatcher rd = request.getRequestDispatcher("NomalSignal.jsp");
					rd.forward(request, response);
				}
				
				else if(action.equals("CalculationSignal")) {
					List<CalculationSignalDTO> CalculationSignallist = tdao.CalculationSignallist();
					request.setAttribute("CalculationSignallist", CalculationSignallist);
				
					RequestDispatcher rd = request.getRequestDispatcher("CalculationSignal.jsp");
					rd.forward(request, response);
				}
				
				else if(action.equals("CountSignal")) {
					List<CountSignalDTO> CountSignallist = tdao.CountSignallist();
					request.setAttribute("CountSignallist", CountSignallist);
				
					RequestDispatcher rd = request.getRequestDispatcher("CountSignal.jsp");
					rd.forward(request, response);
				}
				
				else if(action.equals("NomalSignalAdd")) {
					String Signal = request.getParameter("Signal");
					String TagName = request.getParameter("TagName");
					String SigName = request.getParameter("SigName");
					String Description = request.getParameter("Description");
					String EquipmentName = request.getParameter("EquipmentName");
					String SigType = request.getParameter("SigType");
					String EngLow  = request.getParameter("EngLow");
					String EngHigh  = request.getParameter("EngHigh");
					String Unit  = request.getParameter("Unit");
					String StayTime  = request.getParameter("StayTime");
					String LL  = request.getParameter("LL");
					String L  = request.getParameter("L");
					String H  = request.getParameter("H");
					String HH  = request.getParameter("HH");
					String Alarm  = request.getParameter("Alarm");
					String DI = request.getParameter("DI");
					String SourceTagName  = request.getParameter("SourceTagName");
					String SignalBit  = request.getParameter("SignalBit");
					String DecimalPoint  = request.getParameter("DecimalPoint");
				
					tdao.NomalSignalAdd(Signal, TagName, SigName, Description, EquipmentName, SigType, EngLow, EngHigh, Unit, StayTime, LL, L, H, HH, Alarm,DI,SourceTagName, SignalBit, DecimalPoint );
					
					RequestDispatcher rd = request.getRequestDispatcher("NomalSignalAdd.jsp");
					rd.forward(request, response);
					
				}
				
				else if(action.equals("CalculationSignalAdd")) {
					String calctagName = request.getParameter("calctagName");
					String EquipmentName = request.getParameter("EquipmentName");
					String EngLow = request.getParameter("EngLow");
					String EngHigh = request.getParameter("EngHigh");
					String Unit = request.getParameter("Uint");
					String Description = request.getParameter("Description");
					String Calculation = request.getParameter("Calculation");
					String L = request.getParameter("L");
					String H = request.getParameter("H");
					String DecimalPoint = request.getParameter("DecimalPoint");
					String Alarm = request.getParameter("Alarm");
					String Signal = request.getParameter("Signal");
					
					tdao.CalculationSignalAdd(calctagName, EquipmentName, EngLow, EngHigh, Unit, Description, Calculation, L, H, DecimalPoint, Alarm, Signal);
					
					RequestDispatcher rd = request.getRequestDispatcher("CalculationSignalAdd.jsp");
					rd.forward(request, response);
				}
				
				
				

		}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	}

	

}
