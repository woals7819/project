package com;

public class CalculationSignalDTO {
	private int tagnumber;
	private String signal;
	private String equipmentname;
	private String calctagname;
	private String description;
	private String calculation;
	private int englow;
	private int enghigh;
	private String unit;
	private String alarm;
	private int l;
	private int h;
	private int decimalpoint;
	
	
	
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public String getSignal() {
		return signal;
	}
	public void setSignal(String signal) {
		this.signal = signal;
	}
	public String getEquipmentname() {
		return equipmentname;
	}
	public void setEquipmentname(String equipmentname) {
		this.equipmentname = equipmentname;
	}
	
	public String getCalctagname() {
		return calctagname;
	}
	public void setCalctagname(String calctagname) {
		this.calctagname = calctagname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCalculation() {
		return calculation;
	}
	public void setCalculation(String calculation) {
		this.calculation = calculation;
	}
	public int getEnglow() {
		return englow;
	}
	public void setEnglow(int englow) {
		this.englow = englow;
	}
	public int getEnghigh() {
		return enghigh;
	}
	public void setEnghigh(int enghigh) {
		this.enghigh = enghigh;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getAlarm() {
		return alarm;
	}
	public void setAlarm(String alarm) {
		this.alarm = alarm;
	}
	public int getL() {
		return l;
	}
	public void setL(int l) {
		this.l = l;
	}
	public int getH() {
		return h;
	}
	public void setH(int h) {
		this.h = h;
	}
	public int getDecimalpoint() {
		return decimalpoint;
	}
	public void setDecimalpoint(int decimalpoint) {
		this.decimalpoint = decimalpoint;
	}
	
	
	
	

}
