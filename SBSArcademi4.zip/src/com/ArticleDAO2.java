package com;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class ArticleDAO2 {
	SqlSessionFactory sqlSessionFactory = null;
	
	
	
	public ArticleDAO2() throws IOException {
		String resource = "com/Mybatis.xml";
		InputStream inputStream = Resources.getResourceAsStream(resource);
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
	}
	
	/*========================================List=======================================*/
	public ArrayList<Article> getArticles(){
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		ArrayList<Article> articles =  mapper.getSelectArticles();
		
		return articles;
	}
	/*========================================Add=======================================*/
	public void addArticle(String title, String body, int mid) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("title", title);
		param.put("body", body);
		param.put("mid", mid);
		
		mapper.addArticle(param);
		session.commit(); //commit이 꺼져있으면 DB에 적용이 안됨
 	}
	
	/*========================================Update=======================================*/
	public void updateArticle(String title, String body, int number) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("title", title);
		param.put("body", body);
		param.put("number", number);
		
		mapper.updateArticle(param);
		session.commit();
		
		
	}
	
	/*========================================GetArticle=======================================*/
	public Article getArticleById(int aid) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		
		Article articles = mapper.getArticleById(aid);
		
		return articles;
	}
	/*========================================Delete=======================================*/
	public void deleteArticleById(int aid) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		mapper.deleteArticleById(aid);
		session.commit();
	}
	
	public void deleteReplyById(int aid) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		mapper.deleteReplyById(aid);
		session.commit();
	}

	
	
	/*========================================Reply=======================================*/
	public ArrayList<Reply> getReplies(int aid){
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		ArrayList<Reply> replys = mapper.getReplies(aid);
		
		return replys;
	}
	
	public void replyDelete(int id) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		mapper.replyDelete(id);
		
		session.commit();
		
	}
	
	public void putArticleReply(int aid, int mid, String reply) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("aid", aid);
		param.put("mid", mid);
		param.put("reply", reply);
		
		mapper.putArticleReply(param);
		session.commit();
	}
	
	
	/*========================================SignUp=======================================*/
	public void addMember(String id, String pw, String nick) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		
		Map<String, Object> param = new HashMap<String,Object>();
		param.put("id", id);
		param.put("pw", pw);
		param.put("nick", nick);
		mapper.addMember(param);
		
		session.commit();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
