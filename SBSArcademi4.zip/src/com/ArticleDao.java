package com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

// DB 관련 로직 처리
public class ArticleDao {

	Connection conn = null;

	// JDBC 접속 정보
	// ====================== DB 접속 정보============================================
	String url = "jdbc:mysql://127.0.0.1:3306/t1?serverTimezone=UTC"; // 접속할 DBMS 주소
	String id = "sbsst";
	String pw = "sbs123414";
	// ==============================================================================

	// ===============================접속 시도======================================
	private Connection getConnection() throws ClassNotFoundException, SQLException {
		if (conn == null) {
			Class.forName("com.mysql.cj.jdbc.Driver"); // mysqlDriver 를 찾아야합니다.
			conn = DriverManager.getConnection(url, id, pw); // 특정 DBMS에 접속
		}

		return conn;
		// ==============================================================================
	}
//	public void updateArticle(String title, String body, String number) throws ClassNotFoundException, SQLException {
//		Statement stmt = getConnection().createStatement();
//		
//		String sql = "update article set title = '"+title+"', body = '"+body+"' where id ="+ number;
//		
//		stmt.executeUpdate(sql);
//		
//		if(stmt != null) {
//			stmt.close();
//		}
//	}
	
//	public void deleteArticle(String number) throws ClassNotFoundException, SQLException {
//		Statement stmt = getConnection().createStatement();
//		
//		String sql = "DELETE FROM article\r\n" + 
//				"WHERE id="+ number;
//		
//		stmt.executeUpdate(sql);
//		
//		if(stmt != null) {
//			stmt.close();
//		}
//	}
	
	
//	// 게시물 등록
//	public void addArticle(String title, String body, String mid) throws SQLException, ClassNotFoundException {
//
//		Statement stmt = getConnection().createStatement();
//
//		String sql = "INSERT INTO article \r\n" + "SET title = '" + title + "',\r\n" + "`body` = '" + body + "',\r\n"
//				+ "`mid` = "+mid+",\r\n" + "hit = 0,\r\n" + "regDate = NOW()";
//		// 조회 결과가 있는 경우 : select -> executeQuery() - ResultSet으로 리턴
//		// 조회 결과가 없는 경우 : update, delete, insert -> executeUpdate() - 리턴 X
//		stmt.executeUpdate(sql);
//
//		if (stmt != null) {
//			stmt.close();
//		}
//
//	}

//	// 게시물 목록 조회
//	public ArrayList<Article> ArticleList() throws SQLException, ClassNotFoundException {
//
//		Statement stmt = getConnection().createStatement();
//		String sql = "SELECT * FROM article a\r\n" + 
//				"INNER JOIN `member` m\r\n" + 
//				"ON m.id = a.mid";
//		ResultSet rs = stmt.executeQuery(sql);
//
//		ArrayList<Article> articles = new ArrayList<>();
//
//		while (rs.next()) {
//			// 커서를 이동했을 때 결과 있으면 true, false
//
//			Article a = new Article();
//
//			a.setId(rs.getInt("id"));
//			a.setTitle(rs.getString("title"));
//			a.setBody(rs.getString("body"));
//			a.setNickname(rs.getString("nickname"));
//			a.setHit(rs.getInt("hit"));
//			a.setRegDate(rs.getString("regDate"));
//
//			articles.add(a);
//
//		}
//
//		if (rs != null) {
//			rs.close();
//		}
//		if (stmt != null) {
//			stmt.close();
//		}
//
//		return articles;
//	}

	// 회원가입
	public void addMember(String id, String pw, String nick) throws ClassNotFoundException, SQLException {
		Statement stmt = getConnection().createStatement();
		String sql = "INSERT INTO `member`\r\n" + "SET loginId = '" + id + "',\r\n" + "loginPw = '" + pw + "',\r\n"
				+ "nickname = '" + nick + "',\r\n" + "regDate = NOW()";

		stmt.executeUpdate(sql);
		if (stmt != null) {
			stmt.close();
		}
	}

	// 로그인
	public Member loginCheck(String id, String pw) throws ClassNotFoundException, SQLException {
		Statement stmt = getConnection().createStatement();
		String sql = "SELECT * FROM `member` WHERE loginId = '" + id + "' AND loginPw = '" + pw + "'";

		ResultSet rs = stmt.executeQuery(sql);
		// 단건은 if로 next 처리
		Member m = null;

		if (rs.next()) {
			// m.loginId = rs.getString("loginId");
			m = new Member();
			m.setId(rs.getInt("id"));
			m.setLoginId(rs.getString("loginId"));
			m.setNickname(rs.getString("nickname"));
		}

		if (stmt != null) {
			stmt.close();
		}

		return m;
	}
	
	
	
	

//	// 특정 게시물 가져오기
//	public Article getArticleById(String aid) throws ClassNotFoundException, SQLException {
//
//		Statement stmt = getConnection().createStatement();
//		String sql = "SELECT * FROM article a\r\n" + 
//				"INNER JOIN `member` m\r\n" + 
//				"ON m.id = a.mid\r\n" + 
//				"WHERE a.id=" + aid;
//		ResultSet rs = stmt.executeQuery(sql);
//
//		Article a = new Article();
//
//		if (rs.next()) {
//			a.setId(rs.getInt("id"));
//			a.setTitle(rs.getString("title"));
//			a.setBody(rs.getString("body"));
//			a.setNickname(rs.getString("nickname"));
//			a.setHit(rs.getInt("hit"));
//			a.setRegDate(rs.getString("regDate"));
//
//		}
//
//		return a;
//	}
	
//	public void replyDelete(String id) throws ClassNotFoundException, SQLException {
//		Statement stmt = getConnection().createStatement();
//		
//		String sql = "DELETE FROM reply\r\n" + 
//				"WHERE id ="+id;
//		
//		stmt.executeUpdate(sql);
//		
//	}
	
//	
//	public void putArticleReply(String aid, String mid, String reply) throws ClassNotFoundException, SQLException {
//		Statement stmt = getConnection().createStatement();
//		
//		String sql = "INSERT INTO reply\r\n" + 
//				"SET aid = "+aid+",\r\n" + 
//				"`body` = '"+reply+"',\r\n" + 
//				"`mid` = "+mid+",\r\n" + 
//				"regDate = NOW()";
//		
//		stmt.executeUpdate(sql);
//	}

//	// 댓글 목록 가져오기
//	public ArrayList<Reply> getReplies(String aid) throws ClassNotFoundException, SQLException {
//		Statement stmt = getConnection().createStatement();
//		String sql = "SELECT r.*, m.nickname \r\n" + "FROM reply r\r\n" + "INNER JOIN `member` m\r\n"
//				+ "ON r.mid = m.id\r\n" + "WHERE r.aid = " + aid;
//
//		ResultSet rs = stmt.executeQuery(sql);
//
//		ArrayList<Reply> replies = new ArrayList<>();
//
//		while (rs.next()) {
//			// 커서를 이동했을 때 결과 있으면 true, false
//
//			Reply r = new Reply();
//
//			r.setId(rs.getInt("id"));
//			r.setAid(rs.getInt("aid"));
//			r.setBody(rs.getString("body"));
//			r.setMid(rs.getInt("mid"));
//			r.setRegDate(rs.getString("regDate"));
//			r.setNickname(rs.getString("nickname"));
//
//			replies.add(r);
//
//		}
//
//		if (rs != null) {
//			rs.close();
//		}
//		if (stmt != null) {
//			stmt.close();
//		}
//
//		return replies;
//	}

//	public void deleteArticleById(int aid) throws ClassNotFoundException, SQLException {
//		//Statement stmt = getConnection().createStatement();
//		Connection conn = getConnection();
//		Statement stmt = conn.createStatement();
//		String sql1 = "delete from article where id = " + aid;
//		String sql2 = "delete from reply where id = " + aid;
//		String sql3 = "delete from `like` where id = " + aid;
//		
//		conn.setAutoCommit(false);
//		
//		stmt.executeUpdate(sql1);
//		stmt.executeUpdate(sql2);
//		stmt.executeUpdate(sql3);
//		
//		conn.commit();
//
//		if (stmt != null) {
//			stmt.close();
//		}
//
//	}
	

}