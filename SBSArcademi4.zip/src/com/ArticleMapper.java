package com;

import java.util.ArrayList;
import java.util.Map;


public interface ArticleMapper {
	//1.sql
	//2.리턴
	//3.매개변수
	
	ArrayList<Article> getSelectArticles();
	
	//매개변수는 하나로. -> 파라미터 묶어야 함 1.map ,2.dto
	public void addArticle(Map<String, Object> param);
	/*========================================Update=======================================*/
	public void updateArticle(Map<String, Object> param);
	
	/*========================================Delete=======================================*/
	public void deleteArticleById(int aid);
	public void deleteReplyById(int aid);
	
	/*========================================GetArticle=======================================*/
	public Article getArticleById(int aid);
	
	/*========================================Reply=======================================*/
	public ArrayList<Reply> getReplies(int aid);
	public void replyDelete(int id);
	public void putArticleReply(Map<String, Object> param);
	
	/*========================================SignUp=======================================*/
	public void addMember(Map<String, Object> param);
}
