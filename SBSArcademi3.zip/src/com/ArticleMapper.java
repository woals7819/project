package com;

import java.util.ArrayList;
import java.util.Map;


public interface ArticleMapper {
	//1.sql
	//2.리턴
	//3.매개변수
	
	ArrayList<Article> getSelectArticles();
	
	//매개변수는 하나로. -> 파라미터 묶어야 함 1.map ,2.dto
	public void addArticle(Map<String, Object> param);
	public void addArticle2(Article param);
	
	
}
