package com;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class ArticleDAO2 {
	SqlSessionFactory sqlSessionFactory = null;
	
	
	
	public ArticleDAO2() throws IOException {
		String resource = "com/Mybatis.xml";
		InputStream inputStream = Resources.getResourceAsStream(resource);
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
	}
	
	
	public ArrayList<Article> getArticles(){
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		ArrayList<Article> articles =  mapper.getSelectArticles();
		
		return articles;
	}
	
	public void addArticle(String title, String body, int mid) {
		SqlSession session = sqlSessionFactory.openSession();
		ArticleMapper mapper =  session.getMapper(ArticleMapper.class); //담을 dto
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("title", title);
		param.put("body", body);
		param.put("mid", mid);
		
		mapper.addArticle(param);
		session.commit(); //commit이 꺼져있으면 DB에 적용이 안됨
 	};
}
