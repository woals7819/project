package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.tribes.group.Response;

import sun.security.ec.ECDSAOperations.Seed;

@WebServlet("/Ex")
public class Ex extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		response.setContentType("text/html; charset=utf-8"); 
		PrintWriter out  = response.getWriter();
		
		ArticleDao adao = new ArticleDao();
		ArticleDAO2 adao2 = new ArticleDAO2();
		String action =request.getParameter("action") ;
		try {
			
			/*========================================list==============================================*/
			if(action.equals("list")) {
				ArrayList<Article> articles = adao2.getArticles();
				//데이터 담기
				
				request.setAttribute("List", articles);
//			ArrayList<Article> list = (ArrayList<Article>)request.getAttribute("List");
				
				// 요청데이터 넘기기
				RequestDispatcher rd = request.getRequestDispatcher("ArticleList.jsp");
				rd.forward(request, response);	
			}
			
			
			/*========================================Add==============================================*/
			else if(action.equals("insert")) {
				String title = request.getParameter("title");
				String body = request.getParameter("body");
				int mid = Integer.parseInt(request.getParameter("mid"));
				
				adao2.addArticle(title, body, mid);
				
				response.sendRedirect("Ex?action=list");
				//요청이 이어질 때 포워딩
				//다른페이지를 재요청할 때 리다이렉팅으로 사용한다.
				//리다이렉트
				//response.sendRedirect("Ex?action=list");
			}
			
			
			
			/*========================================Update==============================================*/
			else if(action.equals("update")) {
				String id = request.getParameter("id");
				String title = request.getParameter("title");
				String body = request.getParameter("body");
				
				adao.updateArticle(title, body, id);
				
				response.sendRedirect("Ex?action=list");
			}
			
			else if(action.equals("ArticleUpdate")) {
				String id = request.getParameter("id");
				
				Article articles = adao.getArticleById(id);
				
				request.setAttribute("articles", articles);
				
				RequestDispatcher rd = request.getRequestDispatcher("ArticleUpdate.jsp");
				rd.forward(request, response);
				
			}
			
			
			/*========================================Delete==============================================*/
			else if(action.equals("ArticleDelete")) {
				String id = request.getParameter("id");

				adao.deleteArticle(id);
				
				response.sendRedirect("Ex?action=list");
				
			}
			
			/*========================================Deteil==============================================*/
			else if(action.equals("ArticleDeteil")) {
				String id = request.getParameter("id");
				
				
				HttpSession session = request.getSession();
				Member member = (Member)session.getAttribute("member");
				
				if(member != null) {
					ArrayList<Reply> replylist =  adao.getReplies(id);
					
					request.setAttribute("replylist", replylist);
					
					Article articles = adao.getArticleById(id);
					request.setAttribute("articles", articles);
					RequestDispatcher rd = request.getRequestDispatcher("ArticleDeteil.jsp");
					rd.forward(request, response);
				}
				else {
					response.sendRedirect("MemberSignin.jsp");
				}
				
			}
			
			/*========================================Signup==============================================*/
			else if(action.equals("Signup")) {
				String loginid = request.getParameter("loginid");
				String loginpw = request.getParameter("loginpw");
				String nickname = request.getParameter("nickname");
				
				adao.addMember(loginid, loginpw, nickname);
				
				response.sendRedirect("index.jsp");
			}
			/*========================================Signin==============================================*/
			else if(action.equals("Signin")) {
				String loginid = request.getParameter("loginid");
				String loginpw = request.getParameter("loginpw");
				
				Member member = adao.loginCheck(loginid, loginpw);
				
				
				if(member != null) {
					HttpSession session = request.getSession();
					
					session.setAttribute("member", member);
					
					response.sendRedirect("Ex?action=list");
				}
				else {
					//로그아웃할때 -> (세션의 내용을 지워버림)session.invalidate();
					RequestDispatcher rd = request.getRequestDispatcher("LoginError.jsp");
					rd.forward(request, response);
				}
			}
			
			/*========================================Logout==============================================*/
			else if(action.equals("logout")) {
				HttpSession session = request.getSession();
				
				session.invalidate();
				
				response.sendRedirect("index.jsp");
			}
			
			
			/*========================================Reply==============================================*/
			else if(action.equals("ArticleReply")) {
				String reply = request.getParameter("reply");
				String aid = request.getParameter("aid");
				String mid = request.getParameter("mid");
				

				adao.putArticleReply(aid, mid, reply);
				
				RequestDispatcher rd = request.getRequestDispatcher("Ex?action=ArticleDeteil&id="+aid);
				rd.forward(request, response);
			}
			
			else if(action.equals("replydelete")) {
				String id = request.getParameter("id");
				String aid = request.getParameter("aid");
				
				adao.replyDelete(id);
				
				RequestDispatcher rd = request.getRequestDispatcher("Ex?action=ArticleDeteil&id="+aid);
				rd.forward(request, response);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

				
	}



}
